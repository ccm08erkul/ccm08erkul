VippsTimer v1.1

How to use:
1. Double-click vippstimer_v1_1.exe
2. Add as Window Capture in OBS
3. Set Chroma Key to #000001
4. Do NOT move the exe without the sounds folder

Admin password: ccm2026